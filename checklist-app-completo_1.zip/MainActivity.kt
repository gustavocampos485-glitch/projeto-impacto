package com.checklist.supervisao.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import android.widget.Button
import android.widget.TextView
import androidx.lifecycle.ViewModelProvider
import com.checklist.supervisao.R
import com.checklist.supervisao.data.database.ChecklistDatabase
import com.checklist.supervisao.data.repository.ChecklistRepository
import com.checklist.supervisao.ui.viewmodel.ChecklistViewModel
import com.checklist.supervisao.ui.viewmodel.ChecklistViewModelFactory

class MainActivity : AppCompatActivity() {
    
    private lateinit var viewModel: ChecklistViewModel
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        // Inicializa ViewModel
        val database = ChecklistDatabase.getDatabase(this)
        val repository = ChecklistRepository(database.checklistDao())
        viewModel = ViewModelProvider(
            this,
            ChecklistViewModelFactory(repository)
        ).get(ChecklistViewModel::class.java)
        
        setupUI()
        observeData()
    }
    
    private fun setupUI() {
        val btnNewChecklist = findViewById<Button>(R.id.btnNewChecklist)
        val btnViewHistory = findViewById<Button>(R.id.btnViewHistory)
        val btnAbout = findViewById<Button>(R.id.btnAbout)
        val tvWelcome = findViewById<TextView>(R.id.tvWelcome)
        
        btnNewChecklist.setOnClickListener {
            val intent = Intent(this, ChecklistActivity::class.java)
            startActivity(intent)
        }
        
        btnViewHistory.setOnClickListener {
            val intent = Intent(this, HistoryActivity::class.java)
            startActivity(intent)
        }
        
        btnAbout.setOnClickListener {
            showAboutDialog()
        }
    }
    
    private fun observeData() {
        lifecycleScope.launchWhenStarted {
            viewModel.checklists.collect { checklists ->
                val tvStatus = findViewById<TextView>(R.id.tvStatus)
                tvStatus.text = "Checklists realizadas: ${checklists.size}"
            }
        }
    }
    
    private fun showAboutDialog() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Sobre o Aplicativo")
            .setMessage(R.string.msg_about)
            .setIcon(android.R.drawable.ic_dialog_info)
            .setPositiveButton("OK", null)
            .show()
    }
}
