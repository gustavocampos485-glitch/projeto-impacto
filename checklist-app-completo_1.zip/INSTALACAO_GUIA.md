# 📱 Guia de Instalação - Aplicativo Android Checklist Supervisão

## 🎯 Objetivo
Este guia irá ajudar você a importar e configurar o aplicativo Android de Checklist de Supervisão no Android Studio.

## ⚙️ Pré-requisitos

Antes de começar, certifique-se que possui:

- **Android Studio** (versão 4.2 ou superior)
- **Java Development Kit (JDK)** 11 ou superior
- **SDK Android** versão 24 ou superior
- **Gradle** (incluído no Android Studio)
- Mínimo 5GB de espaço em disco

## 🚀 Passo 1: Preparar o Projeto

### 1.1 Criar a Estrutura de Diretórios

```
checklist-app/
├── app/
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/checklist/supervisao/
│   │   │   │   ├── data/
│   │   │   │   │   ├── database/
│   │   │   │   │   ├── model/
│   │   │   │   │   └── repository/
│   │   │   │   ├── ui/
│   │   │   │   │   ├── adapter/
│   │   │   │   │   ├── viewmodel/
│   │   │   │   │   └── *.kt (Activities)
│   │   │   │   └── util/
│   │   │   ├── res/
│   │   │   │   ├── layout/
│   │   │   │   ├── values/
│   │   │   │   ├── drawable/
│   │   │   │   └── mipmap/
│   │   │   └── AndroidManifest.xml
│   │   └── test/
│   └── build.gradle
├── build.gradle (root)
├── settings.gradle
└── gradle.properties
```

### 1.2 Criar Arquivos Principais

**build.gradle (Root):**
```gradle
plugins {
    id 'com.android.application' version '8.1.2' apply false
    id 'org.jetbrains.kotlin.android' version '1.9.10' apply false
}
```

**settings.gradle:**
```gradle
pluginManagement {
    repositories {
        gradlePluginPortal()
        google()
        mavenCentral()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

include ':app'
rootProject.name = "Checklist Supervisão"
```

**gradle.properties:**
```properties
org.gradle.jvmargs=-Xmx2048m -XX:MaxPermSize=512m
android.useAndroidX=true
android.enableJetifier=true
kotlin.code.style=official
```

## 🔧 Passo 2: Copiar Arquivos Kotlin

Copie os seguintes arquivos `.kt` para suas respectivas pastas:

### Data Layer:
- `ChecklistData.kt` → `app/src/main/java/com/checklist/supervisao/data/model/`
- `ChecklistDao.kt` → `app/src/main/java/com/checklist/supervisao/data/database/`
- `ChecklistDatabase.kt` → `app/src/main/java/com/checklist/supervisao/data/database/`
- `ChecklistRepository.kt` → `app/src/main/java/com/checklist/supervisao/data/repository/`

### UI Layer:
- `MainActivity.kt` → `app/src/main/java/com/checklist/supervisao/ui/`
- `ChecklistActivity.kt` → `app/src/main/java/com/checklist/supervisao/ui/`
- `HistoryActivity.kt` → `app/src/main/java/com/checklist/supervisao/ui/`
- `ReportActivity.kt` → `app/src/main/java/com/checklist/supervisao/ui/`
- `ChecklistAdapter.kt` → `app/src/main/java/com/checklist/supervisao/ui/adapter/`

### ViewModel:
- `ChecklistViewModel.kt` → `app/src/main/java/com/checklist/supervisao/ui/viewmodel/`

### Utilities:
- `PDFGenerator.kt` → `app/src/main/java/com/checklist/supervisao/util/`

## 🎨 Passo 3: Copiar Arquivos XML (Resources)

### Layout Files:
Copie para `app/src/main/res/layout/`:
- `activity_main.xml`
- `activity_checklist.xml`
- `activity_history.xml`
- `activity_report.xml`
- `item_checklist.xml`

### Values Files:
Copie para `app/src/main/res/values/`:
- `colors.xml`
- `strings.xml`
- `styles.xml`
- `drawables.xml` (ou divida em diferentes arquivos drawable)

### Manifest:
Copie `AndroidManifest.xml` para `app/src/main/`

## ✏️ Passo 4: Configurar build.gradle da App

Edite `app/build.gradle` com as dependências fornecidas:

```gradle
plugins {
    id 'com.android.application'
    id 'kotlin-android'
}

android {
    compileSdk 34
    
    defaultConfig {
        applicationId "com.checklist.supervisao"
        minSdk 24
        targetSdk 34
        versionCode 1
        versionName "1.0.0"
    }
    
    buildTypes {
        release {
            minifyEnabled false
        }
    }
    
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_1_8
        targetCompatibility JavaVersion.VERSION_1_8
    }
    
    kotlinOptions {
        jvmTarget = '1.8'
    }
    
    buildFeatures {
        viewBinding true
    }
}

dependencies {
    // [Cole aqui todas as dependências do arquivo build.gradle fornecido]
}
```

## 🎬 Passo 5: Configurar Emulador ou Dispositivo

### Usar Emulador (Recomendado para testes):

1. Abra Android Studio
2. **Tools** → **Device Manager**
3. Clique em **Create Device**
4. Escolha um modelo (ex: Pixel 4)
5. Selecione API 30 ou superior
6. Clique em **Finish**

### Usar Dispositivo Real:

1. Ative **Modo Desenvolvedor** no seu Android:
   - Configurações → Sobre → Toque 7x em "Versão do Android"

2. Ative **Depuração USB**:
   - Configurações → Opções de Desenvolvimento → Depuração USB

3. Conecte via USB ao computador

## 🔨 Passo 6: Compilar o Projeto

1. Abra Android Studio
2. **File** → **Open** → Selecione a pasta `checklist-app`
3. Aguarde o Android Studio sincronizar o projeto
4. Clique em **Build** → **Make Project**
5. Ou pressione **Ctrl+B**

## ▶️ Passo 7: Executar o Aplicativo

1. Clique no botão **Run** (▶️) na barra de ferramentas
2. Ou pressione **Shift+F10**
3. Selecione o emulador ou dispositivo
4. Clique em **OK**

O aplicativo será compilado e executado no seu dispositivo.

## ✅ Verificar se Funcionou

Após iniciar o app, você deve ver:

1. **Tela Inicial**: Com botões para "Nova Supervisão", "Histórico" e "Sobre"
2. **Contador**: Mostrando "Checklists realizadas: 0"

## 🧪 Teste Rápido

1. Clique em **Nova Supervisão**
2. Preencha os campos (pelo menos os obrigatórios)
3. Role até o final e clique em **Gerar PDF**
4. Verifique a mensagem de sucesso

## 📁 Onde os PDFs são Salvos

Os PDFs são salvos em:
```
/sdcard/Android/data/com.checklist.supervisao/files/Documents/
```

Você pode acessá-los via:
- Android Studio **Device File Explorer**
- Ou qualquer explorador de arquivos no dispositivo

## ❌ Solucionar Problemas

### Erro: "Gradle sync failed"
- Limpe o projeto: **File** → **Invalidate Caches**
- Recrie o projeto

### Erro: "Cannot find symbol"
- Certifique-se que todos os arquivos estão nas pastas corretas
- Reconstrua o projeto

### Erro: "Permissões negadas"
- O app pedirá permissões ao executar
- Conceda as permissões quando solicitado

### Erro: "Device not found"
- Verifique se o emulador está iniciado
- Para dispositivo real: verifique depuração USB

## 📚 Recursos Úteis

- [Documentação Android Oficial](https://developer.android.com/docs)
- [Kotlin for Android](https://kotlinlang.org/docs/android-overview.html)
- [Room Database Guide](https://developer.android.com/training/data-storage/room)
- [iText PDF Library](https://itext.com/developers)

## 🎓 Próximos Passos

1. Explore o código
2. Personalize cores e estilos em `colors.xml` e `styles.xml`
3. Adicione seu logo em `app/src/main/res/mipmap/`
4. Teste em diferentes dispositivos
5. Build release para distribuição

## 📞 Suporte

Se encontrar problemas:
1. Verifique os logs do Android Studio (Logcat)
2. Limpe e reconstrua o projeto
3. Consulte a documentação oficial do Android

---

**Parabéns! Seu aplicativo está pronto para uso! 🎉**
