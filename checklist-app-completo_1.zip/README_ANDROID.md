# Aplicativo Android de Checklist de Supervisão

## 📱 Visão Geral

Aplicativo Android completo para realização de checklists de supervisão em postos de serviço, com geração automática de relatórios em PDF. Funciona 100% offline e armazena dados localmente no banco de dados SQLite/Room.

## 🎯 Características Principais

- ✅ **Offline Completo**: Funciona sem conexão à internet
- ✅ **Banco de Dados Local**: Armazena checklists usando Room Database
- ✅ **Geração de PDF**: Relatórios profissionais em PDF
- ✅ **Histórico Completo**: Visualize todos os checklists realizados
- ✅ **Busca e Filtros**: Pesquise checklists por cliente
- ✅ **Geolocalização**: Captura coordenadas GPS da visita
- ✅ **Interface Profissional**: Design moderno e intuitivo

## 📋 Estrutura do Projeto

```
com.checklist.supervisao/
├── data/
│   ├── database/
│   │   ├── ChecklistDatabase.kt
│   │   └── ChecklistDao.kt
│   ├── model/
│   │   └── ChecklistData.kt
│   └── repository/
│       └── ChecklistRepository.kt
├── ui/
│   ├── MainActivity.kt
│   ├── ChecklistActivity.kt
│   ├── HistoryActivity.kt
│   ├── ReportActivity.kt
│   ├── adapter/
│   │   └── ChecklistAdapter.kt
│   └── viewmodel/
│       └── ChecklistViewModel.kt
└── util/
    └── PDFGenerator.kt
```

## 🚀 Instalação e Configuração

### Pré-requisitos

- Android Studio (versão 4.2 ou superior)
- SDK Android 24+ (API level 24)
- Gradle 7.0+

### Passos de Instalação

1. **Clone o repositório** (ou copie os arquivos)
   ```bash
   git clone <repo-url>
   cd checklist-app
   ```

2. **Abra no Android Studio**
   - File → Open → Selecione a pasta do projeto

3. **Configure as dependências**
   - O Android Studio automaticamente baixará as dependências
   - Se não, execute: `gradle syncNow`

4. **Configure as permissões**
   - As permissões já estão configuradas no `AndroidManifest.xml`
   - O app pedirá permissões em runtime quando necessário

5. **Compile e execute**
   - Clique em "Run" ou pressione Shift+F10
   - Selecione um emulador ou dispositivo conectado

## 📂 Arquivos Principais

### Data Layer

#### `ChecklistDatabase.kt`
- Configuração do Room Database
- Singleton para acesso único ao banco

#### `ChecklistDao.kt`
- Interface DAO (Data Access Object)
- Métodos CRUD para checklists
- Métodos de busca e filtro

#### `ChecklistData.kt`
- Data class com todos os campos do checklist
- Entidade Room para persistência

#### `ChecklistRepository.kt`
- Abstração do acesso aos dados
- Implementa padrão Repository

### UI Layer

#### `MainActivity.kt`
- Tela inicial com menu principal
- Botões para navegar entre funcionalidades
- Exibe quantidade de checklists realizados

#### `ChecklistActivity.kt`
- Formulário completo do checklist
- Captura localização GPS
- Validação de campos obrigatórios
- Integração com ViewModel

#### `HistoryActivity.kt`
- Lista todos os checklists realizados
- Busca e filtros
- Clique para ver detalhes

#### `ReportActivity.kt`
- Visualização do relatório completo
- Botões para gerar PDF
- Opção de compartilhar

### ViewModel

#### `ChecklistViewModel.kt`
- Gerencia estado da aplicação
- Operações assíncronas com coroutines
- Exposição de dados via StateFlow

### Utilities

#### `PDFGenerator.kt`
- Geração de PDFs completos
- Formatação profissional
- Inclui todos os dados do checklist

## 🗄️ Banco de Dados

### Tabela: checklists

| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | Int | ID primário |
| clientName | String | Nome do cliente |
| cnpj | String | CNPJ do cliente |
| address | String | Endereço |
| city | String | Cidade/Estado |
| supervisor | String | Supervisor responsável |
| visitDate | String | Data da visita |
| visitTime | String | Horário da visita |
| contactPerson | String | Responsável no local |
| latitude | Double | Coordenada GPS |
| longitude | Double | Coordenada GPS |
| cleanliness | String | Estado de limpeza |
| equipment | String | Equipamentos (JSON) |
| maintenance | String | Estado de manutenção |
| safety | String | Procedimentos de segurança (JSON) |
| compliance | String | Conformidade |
| staffCount | Int | Quantidade de funcionários |
| staffTraining | String | Nível de treinamento |
| ppe | String | EPIs |
| inventory | String | Gestão de estoque |
| materials | String | Materiais (JSON) |
| observations | String | Observações gerais |
| recommendations | String | Recomendações |
| nextVisit | String | Data próxima visita |
| createdAt | Long | Timestamp criação |
| updatedAt | Long | Timestamp última atualização |
| status | String | Status (DRAFT/COMPLETED) |

## 📱 Fluxo de Uso

### 1. Tela Inicial
- Visualiza estatísticas
- Acessa novo checklist
- Visualiza histórico

### 2. Novo Checklist
- Preenche informações do cliente
- Responde questões do checklist
- Localização é capturada automaticamente

### 3. Revisão e PDF
- Salva no banco de dados
- Gera PDF automaticamente
- Exibe mensagem de sucesso

### 4. Histórico
- Lista todos os checklists
- Busca por cliente
- Visualiza relatório completo

## 🔐 Permissões Requeridas

```xml
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
```

## 🛠️ Dependências Principais

```gradle
// AndroidX
androidx.appcompat:appcompat:1.6.1
androidx.core:core-ktx:1.12.0
androidx.constraintlayout:constraintlayout:2.1.4
androidx.lifecycle:lifecycle-runtime-ktx:2.7.0

// Material Design
com.google.android.material:material:1.11.0

// PDF Generation
com.itextpdf:itext7-core:7.2.5

// Room Database
androidx.room:room-runtime:2.6.1
androidx.room:room-ktx:2.6.1

// JSON Serialization
com.google.code.gson:gson:2.10.1

// WorkManager
androidx.work:work-runtime-ktx:2.9.0
```

## 📄 Layouts XML

| Arquivo | Propósito |
|---------|-----------|
| activity_main.xml | Tela inicial |
| activity_checklist.xml | Formulário do checklist |
| activity_history.xml | Histórico de checklists |
| activity_report.xml | Visualização de relatório |
| item_checklist.xml | Item da lista |

## 🎨 Tema e Estilos

- **Cor Primária**: #667eea
- **Cor Secundária**: #764ba2
- **Cor de Accent**: #f093fb
- **Fonte**: Segoe UI (padrão do sistema)

## 💾 Armazenamento de Dados

- **Local**: `/data/data/com.checklist.supervisao/databases/`
- **PDFs**: `/Documents/` (acessível ao usuário)
- **Tipo**: SQLite via Room ORM

## 🔄 Ciclo de Vida

```
MainActivity
    ↓
ChecklistActivity (novo ou edição)
    ↓
Salva no banco (Room)
    ↓
Gera PDF (iText)
    ↓
ReportActivity (visualização)
    ↓
HistoryActivity (histórico)
```

## 🐛 Troubleshooting

### Erro: "Permission denied"
- Verifique se as permissões estão configuradas no manifest
- Confirme que o usuário concedeu permissões em runtime

### Erro: "Database not found"
- Limpe o cache do app: Settings → Apps → Checklist → Clear Cache
- Desinstale e reinstale o app

### PDF não gerado
- Verifique espaço em disco
- Confirme permissões de escrita
- Verifique se todos os campos obrigatórios estão preenchidos

### Localização não capturada
- Ative GPS no dispositivo
- Verifique permissões de localização
- Aguarde alguns segundos para triangulação

## 📦 Build e Deploy

### Build Debug
```bash
./gradlew assembleDebug
```

### Build Release
```bash
./gradlew assembleRelease
```

### APK Location
- Debug: `app/build/outputs/apk/debug/app-debug.apk`
- Release: `app/build/outputs/apk/release/app-release.apk`

## 🔄 Atualizações Futuras

- [ ] Sincronização com servidor
- [ ] Modo offline com sincronização
- [ ] Assinatura digital no PDF
- [ ] Câmera para fotos
- [ ] Exportação em Excel
- [ ] Notificações de lembretes
- [ ] Análise de histórico

## 📞 Suporte

Para suporte técnico ou reportar bugs, entre em contato com o desenvolvedor.

## 📄 Licença

Este projeto é fornecido como está, para uso interno da empresa.

---

**Versão**: 1.0.0  
**Data**: 2024  
**Desenvolvido com ❤️ em Kotlin**
