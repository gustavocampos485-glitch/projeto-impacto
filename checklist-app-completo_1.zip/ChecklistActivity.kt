package com.checklist.supervisao.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.checklist.supervisao.R
import com.checklist.supervisao.data.database.ChecklistDatabase
import com.checklist.supervisao.data.model.ChecklistData
import com.checklist.supervisao.data.repository.ChecklistRepository
import com.checklist.supervisao.ui.viewmodel.ChecklistViewModel
import com.checklist.supervisao.ui.viewmodel.ChecklistViewModelFactory
import com.checklist.supervisao.util.PDFGenerator
import com.google.gson.Gson
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ChecklistActivity : AppCompatActivity() {
    
    private lateinit var viewModel: ChecklistViewModel
    private var currentLocation: Pair<Double, Double>? = null
    
    private val PERMISSION_REQUEST_CODE = 100
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_checklist)
        
        // Inicializa ViewModel
        val database = ChecklistDatabase.getDatabase(this)
        val repository = ChecklistRepository(database.checklistDao())
        viewModel = ViewModelProvider(
            this,
            ChecklistViewModelFactory(repository)
        ).get(ChecklistViewModel::class.java)
        
        setupPermissions()
        setupUI()
        getCurrentLocation()
    }
    
    private fun setupPermissions() {
        val permissions = arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE
        )
        
        for (permission in permissions) {
            if (ContextCompat.checkSelfPermission(this, permission)
                != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE)
                break
            }
        }
    }
    
    private fun setupUI() {
        val btnGeneratePDF = findViewById<Button>(R.id.btnGeneratePDF)
        val btnClear = findViewById<Button>(R.id.btnClear)
        
        btnGeneratePDF.setOnClickListener {
            saveAndGeneratePDF()
        }
        
        btnClear.setOnClickListener {
            clearForm()
        }
    }
    
    private fun saveAndGeneratePDF() {
        // ===== SEÇÃO 1: INFORMAÇÕES DO CLIENTE =====
        val clientName = findViewById<EditText>(R.id.etClientName).text.toString()
        val cnpj = findViewById<EditText>(R.id.etCNPJ).text.toString()
        val address = findViewById<EditText>(R.id.etAddress).text.toString()
        val city = findViewById<EditText>(R.id.etCity).text.toString()
        val supervisor = findViewById<EditText>(R.id.etSupervisor).text.toString()
        val visitDate = findViewById<EditText>(R.id.etVisitDate).text.toString()
        val visitTime = findViewById<EditText>(R.id.etVisitTime).text.toString()
        
        // Validação básica
        if (clientName.isEmpty() || cnpj.isEmpty() || address.isEmpty() || 
            city.isEmpty() || supervisor.isEmpty() || visitDate.isEmpty() || visitTime.isEmpty()) {
            Toast.makeText(this, "Por favor, preencha todos os campos obrigatórios!", Toast.LENGTH_SHORT).show()
            return
        }
        
        // ===== SEÇÃO 2: CONDIÇÕES FÍSICAS =====
        val cleanliness = getRadioButtonValue(R.id.rgCleanliness)
        val maintenance = getRadioButtonValue(R.id.rgMaintenance)
        val equipment = getCheckedItems(R.id.cgEquipment)
        
        // ===== SEÇÃO 3: CONFORMIDADE - UNIFORME =====
        val uniformCompliance = getRadioButtonValue(R.id.rgUniformCompliance)
        
        // ===== SEÇÃO 4: EQUIPE =====
        val staffPeople = findViewById<EditText>(R.id.etStaffPeople).text.toString()
        val staffPositions = getCheckedItems(R.id.cgStaffPositions)
        val staffTraining = findViewById<Spinner>(R.id.spStaffTraining).selectedItem.toString()
        val staffPPE = getRadioButtonValue(R.id.rgStaffPPE)
        
        // ===== SEÇÃO 5: ESTOQUE =====
        val inventory = getRadioButtonValue(R.id.rgInventory)
        val dmlVerification = getRadioButtonValue(R.id.rgDMLVerification)
        val materials = getCheckedItems(R.id.cgMaterials)
        
        // ===== SEÇÃO 6: OBSERVAÇÕES =====
        val observations = findViewById<EditText>(R.id.etObservations).text.toString()
        val recommendations = findViewById<EditText>(R.id.etRecommendations).text.toString()
        val nextVisit = findViewById<EditText>(R.id.etNextVisit).text.toString()
        
        // Cria objeto ChecklistData
        val checklist = ChecklistData(
            clientName = clientName,
            cnpj = cnpj,
            address = address,
            city = city,
            supervisor = supervisor,
            visitDate = visitDate,
            visitTime = visitTime,
            latitude = currentLocation?.first ?: 0.0,
            longitude = currentLocation?.second ?: 0.0,
            cleanliness = cleanliness,
            equipment = equipment,
            maintenance = maintenance,
            uniformCompliance = uniformCompliance,
            staffPeople = staffPeople,
            staffPositions = staffPositions,
            staffTraining = staffTraining,
            staffPPE = staffPPE,
            inventory = inventory,
            dmlVerification = dmlVerification,
            materials = materials,
            observations = observations,
            recommendations = recommendations,
            nextVisit = nextVisit,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            status = "COMPLETED"
        )
        
        // Salva no banco e gera PDF
        lifecycleScope.launch {
            viewModel.saveChecklist(checklist)
            
            // Gera PDF
            val success = PDFGenerator.generateChecklistPDF(this@ChecklistActivity, checklist)
            
            if (success) {
                Toast.makeText(
                    this@ChecklistActivity,
                    "Checklist salvo e PDF gerado com sucesso!",
                    Toast.LENGTH_LONG
                ).show()
                finish()
            } else {
                Toast.makeText(
                    this@ChecklistActivity,
                    "Erro ao gerar PDF!",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }
    
    private fun getRadioButtonValue(groupId: Int): String {
        val radioGroup = findViewById<RadioGroup>(groupId)
        val selectedId = radioGroup.checkedRadioButtonId
        return if (selectedId != -1) {
            findViewById<RadioButton>(selectedId).text.toString()
        } else {
            ""
        }
    }
    
    private fun getCheckedItems(viewId: Int): String {
        val group = findViewById<LinearLayout>(viewId)
        val items = mutableListOf<String>()
        
        for (i in 0 until group.childCount) {
            val child = group.getChildAt(i)
            if (child is CheckBox && child.isChecked) {
                items.add(child.text.toString())
            }
        }
        
        return Gson().toJson(items)
    }
    
    private fun getCurrentLocation() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            val locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            try {
                val location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                if (location != null) {
                    currentLocation = Pair(location.latitude, location.longitude)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
    
    private fun clearForm() {
        findViewById<EditText>(R.id.etClientName).text.clear()
        findViewById<EditText>(R.id.etCNPJ).text.clear()
        findViewById<EditText>(R.id.etAddress).text.clear()
        findViewById<EditText>(R.id.etCity).text.clear()
        findViewById<EditText>(R.id.etSupervisor).text.clear()
        findViewById<EditText>(R.id.etContactPerson).text.clear()
        findViewById<EditText>(R.id.etStaffCount).text.clear()
        findViewById<EditText>(R.id.etObservations).text.clear()
        findViewById<EditText>(R.id.etRecommendations).text.clear()
    }
}
