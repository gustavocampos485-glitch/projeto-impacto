package com.checklist.supervisao.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.checklist.supervisao.R
import com.checklist.supervisao.data.model.ChecklistData
import com.checklist.supervisao.util.PDFGenerator
import java.text.SimpleDateFormat
import java.util.Locale

class ReportActivity : AppCompatActivity() {
    
    private lateinit var checklist: ChecklistData
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_report)
        
        checklist = intent.getSerializableExtra("checklist") as? ChecklistData ?: return
        
        setupUI()
    }
    
    private fun setupUI() {
        val btnGeneratePDF = findViewById<Button>(R.id.btnGeneratePDF)
        val btnShare = findViewById<Button>(R.id.btnShare)
        val tvReportContent = findViewById<TextView>(R.id.tvReportContent)
        
        tvReportContent.text = formatChecklistContent()
        
        btnGeneratePDF.setOnClickListener {
            val success = PDFGenerator.generateChecklistPDF(this, checklist)
            if (success) {
                Toast.makeText(this, "PDF gerado com sucesso!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Erro ao gerar PDF!", Toast.LENGTH_SHORT).show()
            }
        }
        
        btnShare.setOnClickListener {
            shareReport()
        }
    }
    
    private fun formatChecklistContent(): String {
        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))
        
        return """
            ╔═══════════════════════════════════════════════════════════╗
            ║                 RELATÓRIO DE SUPERVISÃO                  ║
            ║              Checklist de Postos de Serviço               ║
            ║   GRUPO IMPACTO - Serviços Terceirizados                 ║
            ╚═══════════════════════════════════════════════════════════╝
            
            1. INFORMAÇÕES DO CLIENTE
            ───────────────────────────────────────────────────────────
            Cliente/Estabelecimento: ${checklist.clientName}
            CNPJ: ${checklist.cnpj}
            Endereço: ${checklist.address}
            Cidade/Estado: ${checklist.city}
            
            Supervisor Responsável: ${checklist.supervisor}
            Data da Visita: ${formatDate(checklist.visitDate)}
            Horário da Visita: ${checklist.visitTime}
            Localização: Lat ${checklist.latitude}, Long ${checklist.longitude}
            
            2. CONDIÇÕES FÍSICAS
            ───────────────────────────────────────────────────────────
            Estado de Limpeza e Higiene: ${checklist.cleanliness}
            Manutenção Predial: ${checklist.maintenance}
            
            3. CONFORMIDADE - UNIFORME DA EMPRESA
            ───────────────────────────────────────────────────────────
            Utilização de Uniforme: ${checklist.uniformCompliance}
            
            4. EQUIPE E PESSOAL
            ───────────────────────────────────────────────────────────
            Pessoas/Detalhes: ${checklist.staffPeople}
            Nível de Treinamento: ${checklist.staffTraining}
            Uniformes e EPIs: ${checklist.staffPPE}
            
            5. ESTOQUE E MATERIAIS
            ───────────────────────────────────────────────────────────
            Gestão de Estoque: ${checklist.inventory}
            Verificação DML: ${checklist.dmlVerification}
            
            ${if (checklist.observations.isNotEmpty()) {
                """
                6. OBSERVAÇÕES GERAIS
                ───────────────────────────────────────────────────────────
                ${checklist.observations}
                """
            } else ""}
            
            ${if (checklist.recommendations.isNotEmpty()) {
                """
                7. RECOMENDAÇÕES PARA MELHORIA
                ───────────────────────────────────────────────────────────
                ${checklist.recommendations}
                """
            } else ""}
            
            ╔═══════════════════════════════════════════════════════════╗
            ║         GRUPO IMPACTO - Serviços Terceirizados            ║
            ║         Gerado em: ${dateFormat.format(System.currentTimeMillis())}                           ║
            ╚═══════════════════════════════════════════════════════════╝
        """.trimIndent()
    }
    
    private fun formatDate(dateString: String): String {
        return try {
            val inputFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val outputFormat = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))
            val date = inputFormat.parse(dateString)
            outputFormat.format(date ?: System.currentTimeMillis())
        } catch (e: Exception) {
            dateString
        }
    }
    
    private fun shareReport() {
        val intent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_SUBJECT, "Relatório de Supervisão - ${checklist.clientName}")
            putExtra(Intent.EXTRA_TEXT, formatChecklistContent())
            type = "text/plain"
        }
        startActivity(Intent.createChooser(intent, "Compartilhar relatório"))
    }
}
