package com.checklist.supervisao.data.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.checklist.supervisao.data.model.ChecklistData
import kotlinx.coroutines.flow.Flow

@Dao
interface ChecklistDao {
    
    @Insert
    suspend fun insert(checklist: ChecklistData): Long
    
    @Update
    suspend fun update(checklist: ChecklistData)
    
    @Delete
    suspend fun delete(checklist: ChecklistData)
    
    @Query("SELECT * FROM checklists WHERE id = :id")
    suspend fun getChecklistById(id: Int): ChecklistData?
    
    @Query("SELECT * FROM checklists ORDER BY createdAt DESC")
    fun getAllChecklists(): Flow<List<ChecklistData>>
    
    @Query("SELECT * FROM checklists WHERE status = :status ORDER BY createdAt DESC")
    fun getChecklistsByStatus(status: String): Flow<List<ChecklistData>>
    
    @Query("SELECT * FROM checklists WHERE clientName LIKE '%' || :searchQuery || '%' ORDER BY createdAt DESC")
    fun searchChecklists(searchQuery: String): Flow<List<ChecklistData>>
    
    @Query("DELETE FROM checklists WHERE id = :id")
    suspend fun deleteChecklistById(id: Int)
    
    @Query("SELECT COUNT(*) FROM checklists")
    suspend fun getChecklistCount(): Int
}
