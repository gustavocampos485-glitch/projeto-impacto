package com.checklist.supervisao.ui

import android.content.Intent
import android.os.Bundle
import android.widget.ListView
import android.widget.SearchView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.checklist.supervisao.R
import com.checklist.supervisao.data.database.ChecklistDatabase
import com.checklist.supervisao.data.model.ChecklistData
import com.checklist.supervisao.data.repository.ChecklistRepository
import com.checklist.supervisao.ui.adapter.ChecklistAdapter
import com.checklist.supervisao.ui.viewmodel.ChecklistViewModel
import com.checklist.supervisao.ui.viewmodel.ChecklistViewModelFactory
import kotlinx.coroutines.launch

class HistoryActivity : AppCompatActivity() {
    
    private lateinit var viewModel: ChecklistViewModel
    private lateinit var adapter: ChecklistAdapter
    private var allChecklists = listOf<ChecklistData>()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)
        
        // Inicializa ViewModel
        val database = ChecklistDatabase.getDatabase(this)
        val repository = ChecklistRepository(database.checklistDao())
        viewModel = ViewModelProvider(
            this,
            ChecklistViewModelFactory(repository)
        ).get(ChecklistViewModel::class.java)
        
        setupUI()
        observeData()
    }
    
    private fun setupUI() {
        val lvChecklists = findViewById<ListView>(R.id.lvChecklists)
        val svSearch = findViewById<SearchView>(R.id.svSearch)
        
        adapter = ChecklistAdapter(this, emptyList())
        lvChecklists.adapter = adapter
        
        lvChecklists.setOnItemClickListener { _, _, position, _ ->
            val checklist = adapter.getItem(position)
            val intent = Intent(this, ReportActivity::class.java)
            intent.putExtra("checklist", checklist)
            startActivity(intent)
        }
        
        svSearch.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }
            
            override fun onQueryTextChange(newText: String?): Boolean {
                if (newText.isNullOrEmpty()) {
                    adapter.updateList(allChecklists)
                } else {
                    viewModel.searchChecklists(newText)
                }
                return true
            }
        })
    }
    
    private fun observeData() {
        lifecycleScope.launch {
            viewModel.checklists.collect { checklists ->
                allChecklists = checklists
                adapter.updateList(checklists)
            }
        }
    }
}
