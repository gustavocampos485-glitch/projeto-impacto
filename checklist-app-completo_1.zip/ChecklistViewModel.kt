package com.checklist.supervisao.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.checklist.supervisao.data.model.ChecklistData
import com.checklist.supervisao.data.repository.ChecklistRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ChecklistViewModel(private val repository: ChecklistRepository) : ViewModel() {
    
    private val _checklists = MutableStateFlow<List<ChecklistData>>(emptyList())
    val checklists: StateFlow<List<ChecklistData>> = _checklists.asStateFlow()
    
    private val _currentChecklist = MutableStateFlow<ChecklistData?>(null)
    val currentChecklist: StateFlow<ChecklistData?> = _currentChecklist.asStateFlow()
    
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()
    
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()
    
    init {
        loadAllChecklists()
    }
    
    fun loadAllChecklists() {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                repository.getAllChecklists().collect { checklists ->
                    _checklists.value = checklists
                }
            } catch (e: Exception) {
                _error.value = "Erro ao carregar checklists: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }
    
    fun loadChecklistById(id: Int) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val checklist = repository.getChecklistById(id)
                _currentChecklist.value = checklist
            } catch (e: Exception) {
                _error.value = "Erro ao carregar checklist: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }
    
    fun saveChecklist(checklist: ChecklistData) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                if (checklist.id == 0) {
                    repository.insertChecklist(checklist)
                } else {
                    repository.updateChecklist(checklist)
                }
                loadAllChecklists()
            } catch (e: Exception) {
                _error.value = "Erro ao salvar checklist: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }
    
    fun deleteChecklist(checklist: ChecklistData) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                repository.deleteChecklist(checklist)
                loadAllChecklists()
            } catch (e: Exception) {
                _error.value = "Erro ao deletar checklist: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }
    
    fun searchChecklists(query: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                repository.searchChecklists(query).collect { checklists ->
                    _checklists.value = checklists
                }
            } catch (e: Exception) {
                _error.value = "Erro ao buscar checklists: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }
    
    fun clearError() {
        _error.value = null
    }
}

class ChecklistViewModelFactory(private val repository: ChecklistRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return ChecklistViewModel(repository) as T
    }
}
