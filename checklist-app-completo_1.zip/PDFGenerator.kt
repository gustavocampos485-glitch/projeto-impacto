package com.checklist.supervisao.util

import android.content.Context
import android.os.Environment
import com.checklist.supervisao.data.model.ChecklistData
import com.itextpdf.kernel.font.PdfFont
import com.itextpdf.kernel.font.PdfFontFactory
import com.itextpdf.kernel.geom.PageSize
import com.itextpdf.kernel.pdf.PdfDocument
import com.itextpdf.kernel.pdf.PdfWriter
import com.itextpdf.layout.Document
import com.itextpdf.layout.borders.Border
import com.itextpdf.layout.borders.SolidBorder
import com.itextpdf.layout.element.Cell
import com.itextpdf.layout.element.Paragraph
import com.itextpdf.layout.element.Table
import com.itextpdf.layout.properties.HorizontalAlignment
import com.itextpdf.layout.properties.TextAlignment
import com.itextpdf.layout.properties.UnitValue
import com.google.gson.Gson
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PDFGenerator {
    
    fun generateChecklistPDF(context: Context, checklist: ChecklistData): Boolean {
        return try {
            val fileName = "Checklist_${checklist.clientName.replace(" ", "_")}_${System.currentTimeMillis()}.pdf"
            val file = File(
                context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),
                fileName
            )
            
            file.parentFile?.mkdirs()
            
            val writer = PdfWriter(file)
            val pdfDocument = PdfDocument(writer)
            val document = Document(pdfDocument, PageSize.A4)
            document.setMargins(20f, 20f, 20f, 20f)
            
            // Cabeçalho
            val titleFont = PdfFontFactory.createFont()
            val title = Paragraph("RELATÓRIO DE SUPERVISÃO")
                .setFont(titleFont)
                .setFontSize(18f)
                .setBold()
                .setTextAlignment(TextAlignment.CENTER)
            document.add(title)
            
            val subtitle = Paragraph("Checklist de Postos de Serviço")
                .setFont(titleFont)
                .setFontSize(12f)
                .setTextAlignment(TextAlignment.CENTER)
            document.add(subtitle)
            
            val dateInfo = Paragraph("Relatório gerado pelo GRUPO IMPACTO - Serviços Terceirizados")
                .setFont(titleFont)
                .setFontSize(10f)
                .setTextAlignment(TextAlignment.CENTER)
            document.add(dateInfo)
            
            val generatedDate = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR")).format(Date())
            val dateGen = Paragraph("Data: $generatedDate")
                .setFont(titleFont)
                .setFontSize(10f)
                .setTextAlignment(TextAlignment.CENTER)
            document.add(dateGen)
            
            document.add(Paragraph(""))
            
            // Seção 1: Informações do Cliente
            document.add(createSectionTitle("1. INFORMAÇÕES DO CLIENTE"))
            document.add(createInfoTable(
                listOf(
                    Pair("Cliente/Estabelecimento", checklist.clientName),
                    Pair("CNPJ", checklist.cnpj),
                    Pair("Endereço", checklist.address),
                    Pair("Cidade/Estado", checklist.city),
                    Pair("Supervisor Responsável", checklist.supervisor),
                    Pair("Responsável no Local", checklist.contactPerson.ifEmpty { "N/A" }),
                    Pair("Data da Visita", formatDate(checklist.visitDate)),
                    Pair("Horário da Visita", checklist.visitTime),
                    Pair("Localização", "Lat: ${checklist.latitude}, Long: ${checklist.longitude}")
                )
            ))
            
            // Seção 2: Condições Físicas
            document.add(createSectionTitle("2. CONDIÇÕES FÍSICAS DO ESTABELECIMENTO"))
            document.add(createInfoTable(
                listOf(
                    Pair("Estado de Limpeza e Higiene", checklist.cleanliness),
                    Pair("Manutenção Predial", checklist.maintenance)
                )
            ))
            
            document.add(Paragraph("Instalações e Equipamentos:").setBold().setFontSize(11f))
            document.add(createChecklistItems(checklist.equipment))
            
            // Seção 3: Conformidade - Uniforme
            document.add(createSectionTitle("3. CONFORMIDADE - UTILIZAÇÃO DE UNIFORME"))
            document.add(createInfoTable(
                listOf(
                    Pair("Uniforme da Empresa", checklist.uniformCompliance)
                )
            ))
            
            // Seção 4: Equipe e Pessoal
            document.add(createSectionTitle("4. EQUIPE E PESSOAL"))
            document.add(createInfoTable(
                listOf(
                    Pair("Pessoas/Detalhes", checklist.staffPeople),
                    Pair("Nível de Treinamento", checklist.staffTraining),
                    Pair("Uniformes e EPIs", checklist.staffPPE)
                )
            ))
            
            document.add(Paragraph("Cargos Presentes:").setBold().setFontSize(11f))
            document.add(createChecklistItems(checklist.staffPositions))
            
            // Seção 5: Estoque e Materiais
            document.add(createSectionTitle("5. ESTOQUE E MATERIAIS"))
            document.add(createInfoTable(
                listOf(
                    Pair("Gestão de Estoque", checklist.inventory),
                    Pair("Verificação DML", checklist.dmlVerification)
                )
            ))
            
            document.add(Paragraph("Materiais Observados:").setBold().setFontSize(11f))
            document.add(createChecklistItems(checklist.materials))
            
            // Seção 6: Observações
            if (checklist.observations.isNotEmpty()) {
                document.add(createSectionTitle("6. OBSERVAÇÕES GERAIS"))
                document.add(Paragraph(checklist.observations)
                    .setFontSize(10f)
                    .setMarginBottom(15f)
                )
            }
            
            // Seção 7: Recomendações
            if (checklist.recommendations.isNotEmpty()) {
                document.add(createSectionTitle("7. RECOMENDAÇÕES PARA MELHORIA"))
                document.add(Paragraph(checklist.recommendations)
                    .setFontSize(10f)
                    .setMarginBottom(15f)
                )
            }
            
            // Seção 8: Próxima Visita
            if (checklist.nextVisit.isNotEmpty()) {
                document.add(createSectionTitle("8. PRÓXIMA VISITA"))
                document.add(Paragraph("Data Prevista: ${formatDate(checklist.nextVisit)}")
                    .setFontSize(10f)
                )
            }
            
            // Rodapé
            document.add(Paragraph(""))
            document.add(Paragraph("GRUPO IMPACTO - Serviços Terceirizados")
                .setFont(titleFont)
                .setFontSize(10f)
                .setBold()
                .setTextAlignment(TextAlignment.CENTER)
            )
            document.add(Paragraph("Este relatório foi gerado automaticamente pelo Sistema de Checklist de Supervisão")
                .setFontSize(8f)
                .setTextAlignment(TextAlignment.CENTER)
            )
            
            document.close()
            true
            
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
    
    private fun createSectionTitle(title: String): Paragraph {
        return Paragraph(title)
            .setBold()
            .setFontSize(12f)
            .setMarginTop(20f)
            .setMarginBottom(10f)
    }
    
    private fun createInfoTable(items: List<Pair<String, String>>): Table {
        val table = Table(UnitValue.createPercentArray(floatArrayOf(40f, 60f)))
        table.setWidth(UnitValue.createPercentValue(100f))
        
        for ((label, value) in items) {
            val labelCell = Cell()
                .add(Paragraph(label).setBold().setFontSize(10f))
                .setBorder(SolidBorder(0.5f))
                .setPadding(5f)
            
            val valueCell = Cell()
                .add(Paragraph(value).setFontSize(10f))
                .setBorder(SolidBorder(0.5f))
                .setPadding(5f)
            
            table.addCell(labelCell)
            table.addCell(valueCell)
        }
        
        return table
    }
    
    private fun createChecklistItems(jsonArray: String): Paragraph {
        return try {
            val items = Gson().fromJson(jsonArray, Array<String>::class.java).toList()
            val itemsText = items.joinToString("\n") { "✓ $it" }
            Paragraph(itemsText).setFontSize(10f).setMarginBottom(10f)
        } catch (e: Exception) {
            Paragraph("Nenhum item selecionado").setFontSize(10f).setMarginBottom(10f)
        }
    }
    
    private fun formatDate(dateString: String): String {
        return try {
            val inputFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val outputFormat = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))
            val date = inputFormat.parse(dateString)
            outputFormat.format(date ?: Date())
        } catch (e: Exception) {
            dateString
        }
    }
}
