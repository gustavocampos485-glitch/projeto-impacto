package com.checklist.supervisao.ui.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import com.checklist.supervisao.R
import com.checklist.supervisao.data.model.ChecklistData
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ChecklistAdapter(
    context: Context,
    private var checklists: List<ChecklistData>
) : ArrayAdapter<ChecklistData>(context, R.layout.item_checklist, checklists) {
    
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var view = convertView
        
        if (view == null) {
            view = LayoutInflater.from(context).inflate(R.layout.item_checklist, parent, false)
        }
        
        val checklist = checklists[position]
        
        val tvClientName = view.findViewById<TextView>(R.id.tvClientName)
        val tvCNPJ = view.findViewById<TextView>(R.id.tvCNPJ)
        val tvDate = view.findViewById<TextView>(R.id.tvDate)
        val tvStatus = view.findViewById<TextView>(R.id.tvStatus)
        
        tvClientName.text = checklist.clientName
        tvCNPJ.text = "CNPJ: ${checklist.cnpj}"
        
        val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR"))
        tvDate.text = dateFormat.format(Date(checklist.createdAt))
        
        tvStatus.text = when (checklist.status) {
            "COMPLETED" -> "✓ Concluído"
            "DRAFT" -> "◯ Rascunho"
            else -> checklist.status
        }
        
        return view
    }
    
    fun updateList(newChecklists: List<ChecklistData>) {
        checklists = newChecklists
        notifyDataSetChanged()
    }
    
    override fun getCount(): Int = checklists.size
    
    override fun getItem(position: Int): ChecklistData = checklists[position]
}
