package com.checklist.supervisao.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "checklists")
data class ChecklistData(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    
    // ===== SEÇÃO 1: INFORMAÇÕES DO CLIENTE =====
    val clientName: String = "",
    val cnpj: String = "",
    val address: String = "",
    val city: String = "",
    val supervisor: String = "",
    val visitDate: String = "",
    val visitTime: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    
    // ===== SEÇÃO 2: CONDIÇÕES FÍSICAS =====
    val cleanliness: String = "", // Excelente, Bom, Adequado, Inadequado
    val maintenance: String = "", // Perfeito estado, Bom estado, Necessita reparos
    val equipment: String = "", // JSON array serialized
    
    // ===== SEÇÃO 3: CONFORMIDADE - UNIFORME =====
    val uniformCompliance: String = "", // Totalmente conforme, Parcialmente conforme, Não conforme
    
    // ===== SEÇÃO 4: EQUIPE =====
    val staffPeople: String = "", // Detalhes das pessoas
    val staffPositions: String = "", // JSON array de cargos
    val staffTraining: String = "", // Excelente, Bom, Adequado, Insuficiente
    val staffPPE: String = "", // Todos, Maioria, Alguns
    
    // ===== SEÇÃO 5: ESTOQUE =====
    val inventory: String = "", // Bem organizado, Aceitável, Desorganizado
    val dmlVerification: String = "", // Verificação DML - Conforme, Parcial, Não conforme
    val materials: String = "", // JSON array serialized
    
    // ===== SEÇÃO 6: OBSERVAÇÕES =====
    val observations: String = "",
    val recommendations: String = "",
    val nextVisit: String = "",
    
    // ===== METADATA =====
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val status: String = "COMPLETED" // DRAFT, COMPLETED, SUBMITTED
) : Serializable
