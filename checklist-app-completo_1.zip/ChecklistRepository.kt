package com.checklist.supervisao.data.repository

import com.checklist.supervisao.data.database.ChecklistDao
import com.checklist.supervisao.data.model.ChecklistData
import kotlinx.coroutines.flow.Flow

class ChecklistRepository(private val checklistDao: ChecklistDao) {
    
    suspend fun insertChecklist(checklist: ChecklistData): Long {
        return checklistDao.insert(checklist)
    }
    
    suspend fun updateChecklist(checklist: ChecklistData) {
        checklistDao.update(checklist)
    }
    
    suspend fun deleteChecklist(checklist: ChecklistData) {
        checklistDao.delete(checklist)
    }
    
    suspend fun getChecklistById(id: Int): ChecklistData? {
        return checklistDao.getChecklistById(id)
    }
    
    fun getAllChecklists(): Flow<List<ChecklistData>> {
        return checklistDao.getAllChecklists()
    }
    
    fun getChecklistsByStatus(status: String): Flow<List<ChecklistData>> {
        return checklistDao.getChecklistsByStatus(status)
    }
    
    fun searchChecklists(query: String): Flow<List<ChecklistData>> {
        return checklistDao.searchChecklists(query)
    }
    
    suspend fun deleteChecklistById(id: Int) {
        checklistDao.deleteChecklistById(id)
    }
    
    suspend fun getChecklistCount(): Int {
        return checklistDao.getChecklistCount()
    }
}
